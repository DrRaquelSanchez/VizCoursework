# VAforPM_univariateCat
Session on Univariate Categorical visualization
